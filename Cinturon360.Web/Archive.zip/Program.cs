using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

using Cinturon360.Web.Components;
using Cinturon360.Web.Components.Account;
using Cinturon360.Web.Security;  // SeedData
using Cinturon360.Shared.Auth;
using Cinturon360.Shared.Services;
using Cinturon360.Web.Infrastructure.Http;
using Cinturon360.Web.Infrastructure.SMTP.Providers.MailerSend;

namespace Cinturon360.Web;

public class Program
{
    public static async Task Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Add services to the container.
        builder.Services.AddRazorComponents()
            .AddInteractiveServerComponents(); // .NET 9 Interactive Server

        builder.Services.AddCascadingAuthenticationState();
        builder.Services.AddScoped<IdentityUserAccessor>();
        builder.Services.AddScoped<IdentityRedirectManager>();
        builder.Services.AddScoped<AuthenticationStateProvider, IdentityRevalidatingAuthenticationStateProvider>();

        builder.Services.AddHttpContextAccessor();

        builder.Services.AddAuthentication(options =>
            {
                options.DefaultScheme = IdentityConstants.ApplicationScheme;
                options.DefaultSignInScheme = IdentityConstants.ExternalScheme;
            })
            .AddIdentityCookies();

        var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

        builder.Services.AddDatabaseDeveloperPageExceptionFilter();

        // Identity + Roles
        builder.Services.AddIdentityCore<ApplicationUser>(options =>
            {
                options.SignIn.RequireConfirmedAccount = true;

                options.Password.RequiredLength = 8;
                options.Password.RequireDigit = true;
                options.Password.RequireUppercase = false;
                options.Password.RequireNonAlphanumeric = false;

                options.Lockout.MaxFailedAccessAttempts = 5;

                options.User.RequireUniqueEmail = true;
            })
            .AddRoles<IdentityRole>()
            .AddEntityFrameworkStores<ApplicationDbContext>()
            .AddSignInManager()
            .AddDefaultTokenProviders();

        builder.Services.AddScoped<IUserClaimsPrincipalFactory<ApplicationUser>, AppClaimsFactory>();

        // Authorization policies
        builder.Services.AddAuthorization(options =>
        {
            // Sudo always allowed via [Authorize(Roles=AppRoles.Sudo)] if you want.

            // Platform
            options.AddPolicy(AppPolicies.PlatformPolicy.AdminArea, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Platform.SuperAdmin, AppRoles.Platform.Admin, AppRoles.Platform.SuperUser));
            options.AddPolicy(AppPolicies.PlatformPolicy.SupportArea, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Platform.Support.Admin, AppRoles.Platform.Support.Agent, AppRoles.Platform.Support.Viewer, AppRoles.Platform.Support.Finance));
            options.AddPolicy(AppPolicies.PlatformPolicy.FinanceWrite, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Platform.Finance.Admin, AppRoles.Platform.Finance.Editor));
            options.AddPolicy(AppPolicies.PlatformPolicy.FinanceRead, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Platform.Finance.Admin, AppRoles.Platform.Finance.Editor, AppRoles.Platform.Finance.Viewer));
            options.AddPolicy(AppPolicies.PlatformPolicy.SalesArea, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Platform.Sales.Admin, AppRoles.Platform.Sales.Manager, AppRoles.Platform.Sales.Rep));
            options.AddPolicy(AppPolicies.PlatformPolicy.ReportsRead, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Platform.ReportsViewer, AppRoles.Platform.DataExporter, AppRoles.Platform.Auditor, AppRoles.Platform.ReadOnly));
            options.AddPolicy(AppPolicies.PlatformPolicy.DataExport, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Platform.DataExporter));

            options.AddPolicy("Platform:ManageUsers", p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Platform.UserAdmin, AppRoles.Platform.SuperAdmin, AppRoles.Platform.Admin));

            options.AddPolicy("Platform:Finance:Discounts:Create", p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Platform.SuperAdmin, AppRoles.Platform.Finance.Admin, AppRoles.Platform.Sales.Admin, AppRoles.Platform.Sales.Manager));

            // TMC
            options.AddPolicy(AppPolicies.TmcPolicy.AdminArea, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Tmc.Admin, AppRoles.Tmc.UserAdmin, AppRoles.Tmc.PolicyAdmin, AppRoles.Tmc.SecurityAdmin, AppRoles.Tmc.IntegrationAdmin));
            options.AddPolicy(AppPolicies.TmcPolicy.FinanceWrite, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Tmc.Finance.Admin, AppRoles.Tmc.Finance.Editor));
            options.AddPolicy(AppPolicies.TmcPolicy.FinanceRead, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Tmc.Finance.Admin, AppRoles.Tmc.Finance.Editor, AppRoles.Tmc.Finance.Viewer, AppRoles.Tmc.ReadOnly));
            options.AddPolicy(AppPolicies.TmcPolicy.BookingsOps, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Tmc.BookingsManager, AppRoles.Tmc.TravelAgent));
            options.AddPolicy(AppPolicies.TmcPolicy.ReportsRead, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Tmc.ReportsViewer, AppRoles.Tmc.DataExporter, AppRoles.Tmc.Auditor, AppRoles.Tmc.ReadOnly));
            options.AddPolicy(AppPolicies.TmcPolicy.DataExport, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Tmc.DataExporter));

            // Client
            options.AddPolicy(AppPolicies.ClientPolicy.AdminArea, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Client.Admin, AppRoles.Client.UserAdmin, AppRoles.Client.PolicyAdmin, AppRoles.Client.SecurityAdmin, AppRoles.Client.IntegrationAdmin));
            options.AddPolicy(AppPolicies.ClientPolicy.FinanceWrite, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Client.Finance.Admin, AppRoles.Client.Finance.Editor));
            options.AddPolicy(AppPolicies.ClientPolicy.FinanceRead, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Client.Finance.Admin, AppRoles.Client.Finance.Editor, AppRoles.Client.Finance.Viewer, AppRoles.Client.ReadOnly));
            options.AddPolicy(AppPolicies.ClientPolicy.ApproverL1Plus, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Client.Approver.L1, AppRoles.Client.Approver.L2, AppRoles.Client.Approver.L3));
            options.AddPolicy(AppPolicies.ClientPolicy.ApproverL2Plus, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Client.Approver.L2, AppRoles.Client.Approver.L3));
            options.AddPolicy(AppPolicies.ClientPolicy.ApproverL3Only, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Client.Approver.L3));
            options.AddPolicy(AppPolicies.ClientPolicy.ReportsRead, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Client.ReportsViewer, AppRoles.Client.DataExporter, AppRoles.Client.Auditor, AppRoles.Client.ReadOnly));
            options.AddPolicy(AppPolicies.ClientPolicy.DataExport, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Client.DataExporter));
            options.AddPolicy(AppPolicies.ClientPolicy.Requestor, p =>
                p.RequireRole(AppRoles.Sudo, AppRoles.Client.Requestor));

            // Shared
            options.AddPolicy("Shared:BookingSelect", p =>
                p.RequireRole(
                    AppRoles.Sudo,
                    AppRoles.Platform.SuperAdmin, AppRoles.Platform.SuperUser, AppRoles.Platform.Admin, AppRoles.Platform.Support.Admin, AppRoles.Platform.Support.Agent,
                    AppRoles.Tmc.Admin, AppRoles.Tmc.BookingsManager, AppRoles.Tmc.TravelAgent,
                    AppRoles.Client.Admin, AppRoles.Client.Requestor
            ));
        });


        // Cookie options
        builder.Services.ConfigureApplicationCookie(opts =>
        {
            opts.LoginPath = "/Account/Login";
            opts.AccessDeniedPath = "/Account/AccessDenied";
        });

        // DbContext + interceptor
        builder.Services.AddDbContext<ApplicationDbContext>((sp, options) =>
        {
            options.UseNpgsql(connectionString, npg =>
            {
                npg.EnableRetryOnFailure(5, TimeSpan.FromSeconds(2), null);
                npg.CommandTimeout(30);
            });
        });

        // Email Sender (MailerSend)
        builder.Services.Configure<MailerSendEmailOptions>(
            builder.Configuration.GetSection("MailerSend"));

        // Http Clients
        builder.Services.AddHttpClient();
        builder.Services.AddC360ApiHttpClient(builder.Configuration);

        // Services
        builder.Services.PlatformServices();
        builder.Services.AddAvaClientServices();
        builder.Services.AddAvaFinanceServices();
        builder.Services.AddAvaPolicyServices();
        builder.Services.AddTransient<IEmailSender, MailerSendEmailSender>();
        builder.Services.AddTransient<IEmailSender, MailerSendEmailSender>();

        // Web Specific Services
        

        builder.Services.Configure<IdentityOptions>(o =>
        {
            o.SignIn.RequireConfirmedAccount = true;
        });

        // Localization: RESX under /Resources
        builder.Services.AddLocalization(opts => opts.ResourcesPath = "Resources");

        var supportedCultures = new[] { "en-AU", "en-GB", "es-ES", "it-IT", "fr-FR" };
        builder.Services.Configure<RequestLocalizationOptions>(options =>
        {
            options.SetDefaultCulture("en-AU")
                .AddSupportedCultures(supportedCultures)
                .AddSupportedUICultures(supportedCultures);

            options.RequestCultureProviders = new IRequestCultureProvider[]
            {
                new ClaimRequestCultureProvider(),
                new QueryStringRequestCultureProvider { QueryStringKey = "culture" },
                new CookieRequestCultureProvider(),
                new AcceptLanguageHeaderRequestCultureProvider()
            };
        });

        // Detect container
        var inContainer = Environment.GetEnvironmentVariable("DOTNET_RUNNING_IN_CONTAINER") == "true";

        var app = builder.Build();

        // Culture switch endpoint
        app.MapGet("/set-culture", (string culture, string? redirectUri, HttpContext ctx) =>
        {
            ctx.Response.Cookies.Append(
                CookieRequestCultureProvider.DefaultCookieName,
                CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture)),
                new CookieOptions { Expires = DateTimeOffset.UtcNow.AddYears(1), IsEssential = true });

            return Results.Redirect(string.IsNullOrWhiteSpace(redirectUri) ? "/" : redirectUri);
        });

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.UseMigrationsEndPoint();
        }
        else
        {
            app.UseExceptionHandler("/Error");
            if (!inContainer) app.UseHsts();
        }

        if (!inContainer)
        {
            app.UseHttpsRedirection();
        }

        // 1) wwwroot files (images, app.css, etc.)
        app.UseStaticFiles();

        // 2) Localization
        app.UseRequestLocalization(app.Services
            .GetRequiredService<IOptions<RequestLocalizationOptions>>().Value);

        // 3) Auth middlewares
        app.UseAuthentication();
        app.UseAuthorization();

        // 4) Antiforgery
        app.UseAntiforgery();

        // 5) SPA fallback to render NotFound via <Router>, preserving HTTP 404
        //    - Only triggers for non-file paths (no extension) and non-API/framework/content paths
        app.Use(async (ctx, next) =>
        {
            await next();

            if (ctx.Response.StatusCode == StatusCodes.Status404NotFound
                && !ctx.Response.HasStarted                                     // don't touch responses that already started
                && !Path.HasExtension(ctx.Request.Path.Value ?? string.Empty)
                && !ctx.Request.Path.StartsWithSegments("/api")
                && !ctx.Request.Path.StartsWithSegments("/_framework")
                && !ctx.Request.Path.StartsWithSegments("/_content")
                && !ctx.Request.Path.StartsWithSegments("/css")
                && !ctx.Request.Path.StartsWithSegments("/js")
                && !ctx.Request.Path.StartsWithSegments("/images")
                && !ctx.Items.ContainsKey("__spa404_reran"))                     // avoid re-exec loops
            {
                ctx.Items["__spa404_reran"] = true;

                // Preserve 404 for crawlers/SEO, but re-execute the pipeline at '/'
                var originalPath = ctx.Request.Path;
                ctx.Request.Path = "/";

                // Set 404 before re-exec so the final response keeps it unless overwritten before writing
                ctx.Response.StatusCode = StatusCodes.Status404NotFound;

                try
                {
                    await next();                                                // run the rest of the pipeline once more
                }
                finally
                {
                    ctx.Request.Path = originalPath;                             // restore path (optional)
                }
            }
        });

        // 6) Map Razor Components (your app)
        app.MapRazorComponents<App>()
            .AddInteractiveServerRenderMode();

        // 7) Map static web assets for components/framework (/_framework, /_content, *.styles.css)
        //    Allow anonymous so fallback auth policy never blocks scripts/styles.
        app.MapStaticAssets().AllowAnonymous();

        // Identity endpoints
        app.MapAdditionalIdentityEndpoints();

        // Simple logout
        app.MapPost("/auth/logout", async (SignInManager<ApplicationUser> signIn) =>
        {
            await signIn.SignOutAsync();
            return Results.Redirect("/");
        })
        .RequireAuthorization();

        await app.RunAsync();
    }
}
