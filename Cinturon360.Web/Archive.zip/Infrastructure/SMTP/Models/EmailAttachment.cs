namespace Cinturon360.Web.Infrastructure.SMTP.Models;

public sealed class EmailAttachment
{
    public string FileName { get; init; } = string.Empty;
    public byte[] Bytes { get; init; } = Array.Empty<byte>();
}
